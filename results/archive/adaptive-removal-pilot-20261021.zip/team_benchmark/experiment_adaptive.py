"""Frozen three-case pilot for adaptive removal, uniform and no-QUBO controls."""
import argparse
from dataclasses import asdict
import csv
import hashlib
import json
import statistics
import time
from pathlib import Path

import numpy as np

from .audit import audit
from .cached import CachedProblem
from .experimental_adaptive import solve_experimental
from .problem import ROOT, Problem
from .provenance import write_sources
from .report import comparisons
from .run import save
from .solvers import Settings, solve


METHODS = ("hybrid_v2", "adaptive", "uniform", "hybrid_v2_no_qubo", "adaptive_no_qubo")
CASES = ("TC06.json", "TC18.json", "TC20.json")


def export(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    out = args.output.resolve()
    if not out.is_relative_to(ROOT/"results"):
        parser.error("Output must be a new folder under results/")
    if out.exists():
        parser.error("Choose a fresh output folder")
    out.mkdir(parents=True)
    cfg = Settings(seconds=1)
    seeds = list(range(30, 40))
    paths = [ROOT/"members/Rahul/test_cases"/name for name in CASES]
    baseline_hash = hashlib.sha256((ROOT/"team_benchmark/hybrid.py").read_bytes()).hexdigest()
    protocol = dict(cases=list(CASES), selection="Fixed before execution: large fleet, network congestion, simultaneous disruptions.",
                    seeds=seeds, methods=list(METHODS), settings=asdict(cfg), window_policy="hard",
                    hypotheses=["Multiple removal strategies improve over the fixed v2 selector.",
                                "Learning improves over uniform selection of the same four operators.",
                                "An improvement remains when QUBO is disabled in both versions."],
                    removal_operators=["legacy v2 selection", "largest geometric detours", "geographically related customers", "tightest service windows"],
                    learning="Try each arm once, then 20% uniform exploration plus weighted selection. Update selected weight by 0.8 old + 0.2 reward, minimum 0.1; reward = 1 + 100 relative accepted repair gain for improvement, else zero. Reward excludes later QUBO/SA gains.",
                    limits="Exactly the same v2 reinsertion budget, window size, evaluator, initialization, cache, QUBO and time settings. No tuning after execution starts.",
                    scope="Exploratory three-case pilot on previously used supplied fixtures, not independent holdout evidence or a universal performance claim.",
                    production_hybrid_sha256=baseline_hash)
    save(out/"protocol.json", protocol)
    sources = list((ROOT/"team_benchmark").glob("*.py")) + [ROOT/"members/Rahul/run_sb.py", ROOT/"members/Angel/saq_cvrptw.py"]
    manifest = dict(settings=asdict(cfg), methods=list(METHODS), seeds=seeds, window_policy="hard",
                    source_sha256=write_sources(ROOT, sources, out/"sources.zip"),
                    input_sha256={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
    save(out/"manifest.json", manifest)
    rows = []
    for path in paths:
        problem = Problem.load(path)
        for seed in seeds:
            start = time.perf_counter()
            initial = problem.initial(seed)
            construction_seconds = time.perf_counter()-start
            assert problem.evaluate(initial)["feasible"], "Pilot requires shared feasible construction"
            order = METHODS[seed % len(METHODS):] + METHODS[:seed % len(METHODS)]
            for method in order:
                if method.startswith("hybrid_v2"):
                    result = solve(problem, initial, "hybrid_no_qubo" if method.endswith("no_qubo") else "hybrid", seed, cfg)
                else:
                    cached = CachedProblem(problem)
                    result = solve_experimental(cached, initial, "hybrid_no_qubo" if method.endswith("no_qubo") else "hybrid", seed, cfg,
                                                adaptive=method != "uniform")
                    result["stats"].update(route_simulations=cached.route_simulations, route_cache_hits=cached.route_cache_hits)
                result.update(method=method, case=path.name, construction_seconds=construction_seconds)
                checked = audit(problem, result["routes"])
                assert abs(checked["cost"]-result["cost"]) < 1e-7
                assert result["cost"] <= result["initial_cost"] + 1e-7
                result["independent_audit_passed"] = True
                rows.append(result)
                print(f"{path.name} seed={seed} {method}: {result['cost']:.2f} t={result['runtime_seconds']:.4f}", flush=True)
            save(out/"runs.json", rows)
    assert hashlib.sha256((ROOT/"team_benchmark/hybrid.py").read_bytes()).hexdigest() == baseline_hash
    flat = [{k:r[k] for k in ("case", "seed", "method", "cost", "initial_cost", "runtime_seconds", "budget_overrun_seconds", "independent_audit_passed")} for r in rows]
    export(out/"runs.csv", flat)
    paired = comparisons(rows, target="adaptive")
    no_qubo = comparisons([r for r in rows if r["method"] in ("adaptive_no_qubo", "hybrid_v2_no_qubo")], target="adaptive_no_qubo")
    save(out/"paired_comparisons.json", dict(adaptive=paired, no_qubo_control=no_qubo))
    aggregates = []
    for case in CASES:
        for method in METHODS:
            group = [r for r in rows if r["case"] == case and r["method"] == method]
            costs = [r["cost"] for r in group]
            aggregates.append(dict(case=case, method=method, runs=len(group), mean_cost=statistics.mean(costs),
                                   stdev_cost=statistics.stdev(costs), best_cost=min(costs),
                                   mean_seconds=statistics.mean(r["runtime_seconds"] for r in group)))
    export(out/"case_results.csv", aggregates)
    diagnostics = []
    for method in ("adaptive", "uniform", "adaptive_no_qubo"):
        for operator in ("legacy", "worst_detour", "related", "tight_windows"):
            entries = [r["operator_diagnostics"][operator] for r in rows if r["method"] == method]
            diagnostics.append(dict(method=method, operator=operator,
                                    attempts=sum(e["attempts"] for e in entries),
                                    improvements=sum(e["accepted_improvements"] for e in entries),
                                    accepted_gain=sum(e["accepted_gain"] for e in entries)))
    export(out/"operator_diagnostics.csv", diagnostics)
    main_pair = next(p for p in paired if p["vs"] == "hybrid_v2")
    lines = ["# Adaptive destroy-and-repair pilot", "",
             "Isolated experimental file: `team_benchmark/experimental_adaptive.py`. Production `hybrid.py` and dispatch are unchanged. No automatic promotion to the main hybrid.", "",
             "Three previously used cases, ten new seeds (30–39), one second per method, hard windows. Identical initial routes per case/seed; rotating execution order. All 150 final routes passed independent in-run audits. See `audit.json` for saved-result verification.", "",
             "## What changed", "",
             "Four customer-removal operators: the existing v2 selector, worst detours, geographically related customers, and tightest windows. Exact regret reinsertion is unchanged. The adaptive variant learns only from immediately accepted repair gains; QUBO/SA improvements are not credited to the removal operator. Every operator gets a warmup attempt and 20% uniform exploration remains. Weight update and reward are frozen in `protocol.json`.", "",
             "Uniform uses the same operators without learning. V2 and adaptive no-QUBO controls isolate classical repair. No larger route-exchange moves, construction changes, QUBO coefficient changes or sampler changes were introduced.", "",
             "## Per-case mean cost (synthetic INR; lower is better)", "",
             "| Case | V2 | Adaptive | Uniform | V2 no QUBO | Adaptive no QUBO |", "|---|---:|---:|---:|---:|---:|"]
    for case in CASES:
        costs = {r["method"]:r["mean_cost"] for r in aggregates if r["case"] == case}
        lines.append("| "+case+" | "+" | ".join(f"{costs[m]:,.2f}" for m in METHODS)+" |")
    lines += ["", "## Paired assumptions", "",
              "Positive reductions favour the experimental adaptive version. Average seed-paired relative reductions within each case, then average the three cases. Three cases cannot establish statistical superiority; bootstrap intervals with so few, previously used fixtures should be treated as exploratory.", "",
              "| Comparison | Mean reduction | Case wins / ties / losses |", "|---|---:|---:|"]
    for pair in [next(p for p in paired if p["vs"] == "hybrid_v2"), next(p for p in paired if p["vs"] == "uniform"), no_qubo[0]]:
        target = "Adaptive no QUBO" if pair is no_qubo[0] else "Adaptive"
        lines.append(f"| {target} vs {pair['vs']} | {pair['mean_percent']:.3f}% | {pair['wins']} / {pair['ties']} / {pair['losses']} |")
    lines += ["", "## Conclusion", "",
              (f"Adaptive removal reduced average paired cost by {main_pair['mean_percent']:.3f}% relative to v2 in this pilot."
               if main_pair["mean_percent"] > 0 else f"Adaptive removal did not improve average paired cost: reduction versus v2 was {main_pair['mean_percent']:.3f}% in this pilot."),
              "Check the uniform and no-QUBO comparisons before attributing any difference to learning or QUBO. Keep this experimental until broader frozen evaluation supports a change. Do not select only winning seeds/cases. Runtime limits are checked between actions; overruns are recorded.", "",
              "Files: `runs.json` / `.csv`, `case_results.csv`, `operator_diagnostics.csv`, `paired_comparisons.json`, `protocol.json`, `manifest.json`, `sources.zip`, `audit.json` and `comparison.png`."]
    (out/"REPORT.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
    print(out/"REPORT.md", flush=True)


if __name__ == "__main__":
    main()
