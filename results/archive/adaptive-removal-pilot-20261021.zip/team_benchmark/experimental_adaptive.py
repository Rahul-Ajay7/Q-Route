"""Isolated adaptive removal experiment; production hybrid v2 is unchanged.

The search-loop copy below is frozen from hybrid.solve_adaptive. Only customer
removal selection and its diagnostics differ. Exact regret reinsertion, QUBO,
acceptance, deadlines, exclusion and cache settings retain v2 behaviour.
"""
from dataclasses import asdict
import math
import time

import numpy as np

from .problem import sb
from .hybrid import detour, destroy_repair, repair_customers, select_repair_window


OPERATORS = ("legacy", "worst_detour", "related", "tight_windows")


class RemovalPolicy:
    """Four-arm online weighting with warmup and 20% uniform exploration."""
    def __init__(self, seed, adaptive=True):
        self.rng = np.random.default_rng(seed + 100003)
        self.adaptive = adaptive
        self.weights = np.ones(len(OPERATORS))
        self.calls = np.zeros(len(OPERATORS), dtype=int)
        self.successes = np.zeros(len(OPERATORS), dtype=int)
        self.gains = np.zeros(len(OPERATORS))

    def choose(self):
        unseen = np.flatnonzero(self.calls == 0)
        if len(unseen):
            return int(unseen[0])
        probabilities = (0.2/len(OPERATORS) + 0.8*self.weights/self.weights.sum()
                         if self.adaptive else np.full(len(OPERATORS), 1/len(OPERATORS)))
        return int(self.rng.choice(len(OPERATORS), p=probabilities))

    def update(self, arm, before, after):
        gain = max(0.0, before-after)
        self.calls[arm] += 1
        self.successes[arm] += int(gain > 1e-9)
        self.gains[arm] += gain
        reward = 1 + 100*gain/max(abs(before), 1e-9) if gain > 1e-9 else 0
        if self.adaptive:
            self.weights[arm] = max(.1, .8*self.weights[arm] + .2*reward)

    def report(self):
        return {name: dict(attempts=int(self.calls[i]), accepted_improvements=int(self.successes[i]),
                           accepted_gain=float(self.gains[i]), final_weight=float(self.weights[i]))
                for i, name in enumerate(OPERATORS)}


def removal_set(problem, routes, k, excluded, rng, cycle, arm):
    if arm == 0:
        return repair_customers(problem, routes, k, excluded, rng, cycle)
    eligible = [c for route in routes for c in route if c not in excluded]
    if not eligible:
        return []
    ranked = sorted(((detour(problem, route, i), c) for route in routes
                     for i, c in enumerate(route) if c not in excluded), reverse=True)
    if arm == 1:
        return [c for _, c in ranked[:k]]
    if arm == 2:
        anchor = ranked[int(rng.integers(min(3, len(ranked))))][1]
        return sorted(eligible, key=lambda c: (problem.dist[anchor, c], c))[:k]
    if arm == 3:
        # Narrower service-start windows first, with detours as a secondary key.
        pressure = {c: score for score, c in ranked}
        return sorted(eligible, key=lambda c: (
            problem.nodes[c].get("due_time", math.inf) -
            max(problem.nodes[c].get("ready_time", 0), problem.release[c]),
            -pressure[c], c))[:k]
    raise ValueError("Unknown removal arm")


def solve_experimental(problem, initial, method, seed, cfg, adaptive=True):
    # Import lazily to keep the legacy/reference implementation independently callable.
    from .solvers import neighbor, build_qubo
    rng = np.random.default_rng(seed)
    policy = RemovalPolicy(seed, adaptive)
    started = time.perf_counter()
    deadline = started+cfg.seconds
    score = problem.evaluate(initial)
    if not score["feasible"]:
        return dict(method=method,status="NO_FEASIBLE_INITIAL_SOLUTION",seed=seed,
                    routes=[r[:] for r in initial],cost=None,feasible=False,issues=score["issues"],
                    runtime_seconds=time.perf_counter()-started,settings=asdict(cfg),history=[])
    current = [r[:] for r in initial]
    best = [r[:] for r in initial]
    current_cost = best_cost = score["cost"]
    history = [dict(seconds=0.0,cost=best_cost,action="initial")]
    stats = dict(actions=0,route_evaluations=0,sa_moves=0,qubo_calls=0,raw_valid=0,projected=0,
                 accepted_qubo=0,hybrid_cycles=0,max_action_seconds=0.0,repair_calls=0,
                 accepted_repairs=0,qubo_failures=0,repair_seconds=0.0,qubo_seconds=0.0,
                 surrogate_candidates=0,surrogate_infeasible=0)
    temp0 = max(1.0,best_cost/max(1,len(problem.ids))*0.2)
    temp = temp0
    stale = cycle = 0
    interval = cfg.plateau*3
    next_qubo_cycle = 0
    qubo_failure_streak = 0
    tabu, attempted, selections = {},set(),[]
    surrogate_observations = []

    def record(routes,cost,action):
        nonlocal best,best_cost,stale
        if cost < best_cost-1e-9:
            best,best_cost = [r[:] for r in routes],cost
            stale = 0
            history.append(dict(seconds=time.perf_counter()-started,cost=cost,action=action))

    while stats["actions"] < cfg.max_actions and time.perf_counter() < deadline:
        begin = time.perf_counter()
        stats["actions"] += 1
        if stale >= interval and cycle < cfg.cycles:
            current,current_cost = [r[:] for r in best],best_cost
            prior = best_cost
            excluded = {c for c,expiry in tabu.items() if expiry>cycle}
            selected = []
            if method != "hybrid_no_repair":
                arm = policy.choose()
                removed = removal_set(problem,current,cfg.window,excluded,rng,cycle,arm)
                if removed:
                    repair_begin = time.perf_counter()
                    stats["repair_calls"] += 1
                    candidate = destroy_repair(problem,current,removed,deadline)
                    selected.extend(removed)
                    if candidate is not None:
                        value = problem.evaluate(candidate)
                        if value["cost"] < current_cost-1e-9:
                            current,current_cost = candidate,value["cost"]
                            stats["accepted_repairs"] += 1
                            record(current,current_cost,"repair")
                    stats["repair_seconds"] += time.perf_counter()-repair_begin
                    policy.update(arm, prior, current_cost)
            if (method != "hybrid_no_qubo" and cycle>=next_qubo_cycle
                    and time.perf_counter()<deadline):
                pick = select_repair_window(problem,current,cfg.window,excluded,attempted,rng,
                                             method=="hybrid_random")
                if pick is None and attempted:
                    attempted.clear()
                    pick = select_repair_window(problem,current,cfg.window,excluded,attempted,rng,
                                                 method=="hybrid_random")
                if pick is not None:
                    qubo_begin = time.perf_counter()
                    vi,start,end = pick
                    q,_,block = build_qubo(problem,current,vi,start,end)
                    attempted.add((vi,tuple(block)))
                    selections.append(dict(cycle=cycle,customers=block[:],excluded=sorted(excluded)))
                    selected.extend(block)
                    warm = np.eye(len(block)).ravel()
                    backend = sb.solve_sb if cfg.hybrid_backend=="sb" else sb.solve_sa
                    stats["qubo_calls"] += 1
                    bits,scores = backend(q,cfg.samples,cfg.qubo_steps,rng,warm)
                    orders = []
                    for binary,values in zip(bits,scores):
                        order = sb.decode(binary,len(block))
                        if order is None:
                            order = sb.project(values,len(block))
                            stats["projected"] += 1
                        else:
                            stats["raw_valid"] += 1
                        orders.append(tuple(order))
                    before = current_cost
                    warm_energy = float(warm@q@warm)
                    for order in dict.fromkeys(orders):
                        # Bound sampler output validation as well as the search loop.
                        if time.perf_counter()>=deadline:
                            break
                        candidate = [r[:] for r in current]
                        candidate[vi][start:end] = [block[i] for i in order]
                        value = problem.evaluate(candidate)
                        assignment = np.zeros((len(block),len(block)))
                        for pos,i in enumerate(order):
                            assignment[i,pos] = 1
                        x = assignment.ravel()
                        surrogate_observations.append(dict(predicted_gain=warm_energy-float(x@q@x),
                                                           actual_gain=before-value["cost"] if value["feasible"] else None,
                                                           feasible=value["feasible"]))
                        stats["surrogate_candidates"] += 1
                        stats["surrogate_infeasible"] += int(not value["feasible"])
                        stats["route_evaluations"] += len(candidate)
                        if value["feasible"] and value["cost"] < current_cost-1e-9:
                            current,current_cost = candidate,value["cost"]
                            stats["accepted_qubo"] += 1
                            record(current,current_cost,"qubo")
                    if current_cost >= before-1e-9:
                        qubo_failure_streak += 1
                        stats["qubo_failures"] += 1
                    else:
                        qubo_failure_streak = 0
                    next_qubo_cycle = cycle+(1 if method=="hybrid_no_adaptation" else min(8,2**qubo_failure_streak))
                    stats["qubo_seconds"] += time.perf_counter()-qubo_begin
            if method != "hybrid_no_tabu":
                for c in selected:
                    tabu[c] = cycle+cfg.tabu_cycles+1
            if method != "hybrid_no_adaptation":
                interval = cfg.plateau*3 if best_cost<prior-1e-9 else min(cfg.plateau*24,interval*2)
            cycle += 1
            stats["hybrid_cycles"] = cycle
            stale = 0
            temp = temp0
        else:
            candidate = neighbor(current,rng)
            value = problem.evaluate(candidate)
            stats["route_evaluations"] += len(candidate)
            stats["sa_moves"] += 1
            delta = value["cost"]-current_cost
            if value["feasible"] and (delta<=0 or rng.random()<math.exp(-delta/max(temp,1e-9))):
                current,current_cost = candidate,value["cost"]
            stale += 1
            record(current,current_cost,"sa")
            temp = max(temp0*.001,temp*cfg.cooling)
            # Reheat after long stagnation even when the refinement cap is exhausted.
            if cycle>=cfg.cycles and stale>=interval:
                current,current_cost = [r[:] for r in best],best_cost
                temp,stale = temp0,0
        stats["max_action_seconds"] = max(stats["max_action_seconds"],time.perf_counter()-begin)
    elapsed = time.perf_counter()-started
    final = problem.evaluate(best)
    stats["refinement_interval_final"] = interval
    return dict(method=method,status="FEASIBLE",seed=seed,feasible=final["feasible"],cost=final["cost"],
                initial_cost=score["cost"],routes=best,
                metrics={k:final[k] for k in ("distance","travel_minutes","duration_minutes","fuel_liters","lateness_minutes")},
                runtime_seconds=elapsed,budget_overrun_seconds=max(0.0,elapsed-cfg.seconds),
                settings=asdict(cfg),stats=stats,history=history,selections=selections,
                implementation="experimental-adaptive-removal",
                operator_diagnostics=policy.report(), adaptive_removal=adaptive,
                surrogate_observations=surrogate_observations)
