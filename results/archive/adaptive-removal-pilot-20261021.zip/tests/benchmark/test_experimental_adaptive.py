"""Experimental removal must preserve exclusions and full-route safety."""
import copy

import numpy as np
import pytest

from team_benchmark.audit import audit
from team_benchmark.cached import CachedProblem
from team_benchmark.experimental_adaptive import RemovalPolicy, removal_set, solve_experimental
from team_benchmark.problem import Problem
from team_benchmark.solvers import Settings
from .test_team import data


@pytest.mark.parametrize("arm", range(4))
def test_removal_respects_exclusions_and_does_not_mutate(arm):
    problem = Problem(data(6, 2))
    routes = [list(problem.ids[:3]), list(problem.ids[3:])]
    original = copy.deepcopy(routes)
    excluded = {problem.ids[0], problem.ids[-1]}
    selected = removal_set(problem, routes, 3, excluded, np.random.default_rng(7), 1, arm)
    assert len(selected) == len(set(selected)) <= 3
    assert selected and set(selected) <= set(problem.ids)-excluded
    assert removal_set(problem, routes, 3, set(problem.ids), np.random.default_rng(7), 1, arm) == []
    assert routes == original


def test_learning_rewards_success_and_keeps_every_arm_available():
    policy = RemovalPolicy(3)
    for arm in range(4):
        assert policy.choose() == arm
        policy.update(arm, 100, 90 if arm == 2 else 100)
    assert policy.weights[2] > max(policy.weights[[0, 1, 3]])
    selections = [policy.choose() for _ in range(2000)]
    assert set(selections) == set(range(4))
    assert selections.count(2) > max(selections.count(i) for i in (0, 1, 3))


@pytest.mark.parametrize("adaptive,no_qubo", [(True, False), (False, False), (True, True)])
def test_experimental_search_retains_audited_best_and_records_policy(adaptive, no_qubo):
    problem = CachedProblem(Problem(data(6, 2)))
    initial = [list(reversed(problem.ids)), []]
    original = copy.deepcopy(initial)
    cfg = Settings(seconds=10, max_actions=120, plateau=1, samples=2, qubo_steps=3, window=3)
    result = solve_experimental(problem, initial, "hybrid_no_qubo" if no_qubo else "hybrid", 5, cfg,
                                adaptive=adaptive)
    assert result["feasible"]
    assert result["cost"] == pytest.approx(audit(problem, result["routes"])["cost"])
    assert result["cost"] <= result["initial_cost"]
    assert sum(v["attempts"] for v in result["operator_diagnostics"].values()) > 0
    if no_qubo:
        assert result["stats"]["qubo_calls"] == 0
    assert initial == original
