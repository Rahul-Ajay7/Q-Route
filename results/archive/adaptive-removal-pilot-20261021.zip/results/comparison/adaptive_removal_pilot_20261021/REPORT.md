# Adaptive destroy-and-repair pilot

Isolated experimental file: `team_benchmark/experimental_adaptive.py`. Production `hybrid.py` and dispatch are unchanged. No automatic promotion to the main hybrid.

Three previously used cases, ten new seeds (30–39), one second per method, hard windows. Identical initial routes per case/seed; rotating execution order. All 150 final routes passed independent in-run audits. See `audit.json` for saved-result verification.

## What changed

Four customer-removal operators: the existing v2 selector, worst detours, geographically related customers, and tightest windows. Exact regret reinsertion is unchanged. The adaptive variant learns only from immediately accepted repair gains; QUBO/SA improvements are not credited to the removal operator. Every operator gets a warmup attempt and 20% uniform exploration remains. Weight update and reward are frozen in `protocol.json`.

Uniform uses the same operators without learning. V2 and adaptive no-QUBO controls isolate classical repair. No larger route-exchange moves, construction changes, QUBO coefficient changes or sampler changes were introduced.

## Per-case mean cost (synthetic INR; lower is better)

| Case | V2 | Adaptive | Uniform | V2 no QUBO | Adaptive no QUBO |
|---|---:|---:|---:|---:|---:|
| TC06.json | 21,684.73 | 21,804.02 | 21,827.61 | 21,673.40 | 21,786.94 |
| TC18.json | 11,491.61 | 11,357.33 | 11,320.03 | 11,549.54 | 11,421.01 |
| TC20.json | 11,737.13 | 11,694.93 | 11,604.74 | 11,724.50 | 12,010.88 |

## Paired assumptions

Positive reductions favour the experimental adaptive version. Average seed-paired relative reductions within each case, then average the three cases. Three cases cannot establish statistical superiority; bootstrap intervals with so few, previously used fixtures should be treated as exploratory.

| Comparison | Mean reduction | Case wins / ties / losses |
|---|---:|---:|
| Adaptive vs hybrid_v2 | 0.302% | 2 / 0 / 1 |
| Adaptive vs uniform | -0.332% | 1 / 0 / 2 |
| Adaptive no QUBO vs hybrid_v2_no_qubo | -0.652% | 1 / 0 / 2 |

## Conclusion

Adaptive removal reduced average paired cost by 0.302% relative to v2 in this pilot.
Check the uniform and no-QUBO comparisons before attributing any difference to learning or QUBO. Keep this experimental until broader frozen evaluation supports a change. Do not select only winning seeds/cases. Runtime limits are checked between actions; overruns are recorded.

Files: `runs.json` / `.csv`, `case_results.csv`, `operator_diagnostics.csv`, `paired_comparisons.json`, `protocol.json`, `manifest.json`, `sources.zip`, `audit.json` and `comparison.png`.
