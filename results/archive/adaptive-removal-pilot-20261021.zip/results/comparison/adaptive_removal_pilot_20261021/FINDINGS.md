# Adaptive removal experiment: findings and recommendation

## What was implemented

The separate implementation is
[`team_benchmark/experimental_adaptive.py`](../../../team_benchmark/experimental_adaptive.py).
Its isolated search-loop copy keeps v2's SA, QUBO, exact regret reinsertion,
insertion budget, temporary exclusion, caching and deadline behaviour. Only
customer-removal selection and related diagnostics differ. Production
`team_benchmark/hybrid.py` and its dispatcher were not modified.

Four removal strategies are available: the existing v2 selector, worst detours,
geographically related customers, and tight service windows. The adaptive
policy first tries each strategy, then uses reward-based weights with 20%
uniform exploration. Rewards come only from accepted immediate repair gains.
There is no credit for subsequent QUBO or SA improvements.

## Controlled checks

The runner is [`experiment_adaptive.py`](../../../team_benchmark/experiment_adaptive.py).
It compares v2, adaptive selection, uniform selection, v2 without QUBO, and
adaptive selection without QUBO. The uniform control uses the same warmup and
operator set; only learning is disabled.

Cases were chosen before execution: TC06 (large fleet), TC18 (peak-hour network
congestion), TC20 (simultaneous disruptions). These filenames differ from the
internal case IDs; filenames identify comparisons. Ten seeds (30–39), hard
windows, one second per optimization and identical initial routes are used.
Method execution order rotates. No parameters were changed after the pilot began.

All 150 runs were feasible and passed independent saved-result audits.
Source/input hashes matched, and the production hybrid hash remained unchanged.
The full test suite passed 142 tests, including eight new exclusion, policy,
nonmutation and audited-solver checks. This is previously used fixture data,
not an independent real-world holdout.

## Results and assumption verdicts

| Assumption | Observation | Verdict |
|---|---|---|
| The experimental adaptive pipeline improves over v2 | 0.302% lower paired mean cost; two case wins and one loss | Small exploratory gain; insufficient evidence to promote |
| Learning helps beyond using multiple strategies | Adaptive is 0.332% worse than uniform selection; loses on two cases | Not supported in this pilot |
| Improvement persists when QUBO is disabled | Adaptive no-QUBO is 0.652% worse than v2 no-QUBO; loses on two cases | Not supported in this pilot |
| Multiple operators without learning help over v2 | Uniform has lower seed-mean cost on TC18 and TC20, higher cost on TC06 | Mixed, worth testing further; not a general advantage |

Positive reductions in [REPORT.md](REPORT.md) favour adaptive. They average
seed-paired relative differences within each case before averaging cases;
they are not simply ratios of the displayed rounded mean costs.

The new strategies accepted useful repairs: the adaptive runs recorded 446
repair attempts and 112 accepted improvements. The legacy strategy contributed
137 attempts and 37 accepted improvements. These totals show that the new
operators are exercised; they do not establish a causal overall performance
gain. The uniform control remains necessary.

## Recommendation

Keep the current hybrid v2 as the production default. Retain this pilot and
all losses. Do not describe a 0.302% average gain on three familiar cases as
proof of a better algorithm or a QUBO advantage.

The next controlled experiment could compare uniform strategy mixing to v2
on independent cases and longer budgets, and examine reward per unit repair
time rather than accepted gain alone. Changing reward, warmup or operators
would constitute a new version requiring a new frozen protocol and output
folder. Those changes were not made in this pilot.

## Files and reproduction

- [Full report](REPORT.md), [per-case means](case_results.csv), [raw run CSV](runs.csv).
- [Operator diagnostics](operator_diagnostics.csv), [paired statistics](paired_comparisons.json).
- [Comparison graph](comparison.png); whiskers are sample standard deviations.
- [Protocol](protocol.json), [audit](audit.json), [manifest](manifest.json), and `sources.zip`.

```powershell
# Select a fresh output name; the runner never overwrites an existing pilot.
venv\Scripts\python.exe -B -m team_benchmark.experiment_adaptive --output results/comparison/adaptive_removal_pilot_repeat
venv\Scripts\python.exe -B -m team_benchmark.verify_results results/comparison/adaptive_removal_pilot_repeat
```

The experiment runner rebuilds numerical reports. The saved graph is a
visualization of the recorded per-case means and standard deviations; generating
it does not rerun the optimization.
