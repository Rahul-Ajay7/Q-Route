# Controlled team comparison

Exploratory offline benchmark. Lower INR cost is better. These results do not prove universal superiority.

Window policy: **hard**. Optimization budget: **0.25 seconds per run**; identical initial routes per case/seed.

Construction is shared and timed separately. Solver timing includes QUBO building, decoding, projection, and dynamic validation. Atomic actions may overrun the deadline; overruns are recorded.

Current methods share bounded route caching; hybrid_v1_cached uses the old search with the same cache, while hybrid_legacy retains the old uncached implementation. The revised hybrid adds regret-based cross-vehicle repair and adaptive refinement intervals. These are new runs; historical output files are not pooled.

| Method | Feasible / attempted | Mean improvement vs own shared initial (%) | Mean optimization seconds | Max budget overrun (s) |
|---|---:|---:|---:|---:|
| classical_sa | 9 / 9 | 7.30 | 0.2501 | 0.0002 |
| tunnelling_sa | 9 / 9 | 6.86 | 0.2500 | 0.0001 |
| qubo_sb | 9 / 9 | 2.48 | 0.2514 | 0.0025 |
| hybrid | 9 / 9 | 9.39 | 0.2516 | 0.0137 |
| qubo_sa | 9 / 9 | 2.88 | 0.2603 | 0.0308 |
| hybrid_no_tabu | 9 / 9 | 9.13 | 0.2504 | 0.0029 |
| hybrid_random | 9 / 9 | 9.61 | 0.2524 | 0.0185 |
| hybrid_no_qubo | 9 / 9 | 9.13 | 0.2501 | 0.0003 |
| hybrid_legacy | 9 / 9 | 4.71 | 0.2566 | 0.0133 |
| hybrid_v1_cached | 9 / 9 | 5.62 | 0.2520 | 0.0137 |
| hybrid_no_repair | 9 / 9 | 7.38 | 0.2523 | 0.0196 |
| hybrid_no_adaptation | 9 / 9 | 9.54 | 0.2563 | 0.0248 |

## Hybrid paired comparisons

Positive difference favours the hybrid. First average paired relative cost differences across seeds within each case; then compare cases. CI uses a case-level bootstrap; p-values use two-sided Wilcoxon and Holm correction across all comparisons.

| Against | Cases / paired seeds | Hybrid cost reduction % (95% CI) | Case wins / ties / losses | Holm p |
|---|---:|---:|---:|---:|
| classical_sa | 3 / 9 | 2.20 (0.00, 4.92) | 2 / 1 / 0 | 1 |
| hybrid_legacy | 3 / 9 | 4.90 (0.00, 7.35) | 2 / 1 / 0 | 1 |
| hybrid_no_adaptation | 3 / 9 | -0.20 (-1.28, 0.67) | 1 / 1 / 1 | 1 |
| hybrid_no_qubo | 3 / 9 | 0.22 (-1.34, 2.01) | 1 / 1 / 1 | 1 |
| hybrid_no_repair | 3 / 9 | 2.11 (0.00, 5.06) | 2 / 1 / 0 | 1 |
| hybrid_no_tabu | 3 / 9 | 0.27 (-1.03, 1.83) | 1 / 1 / 1 | 1 |
| hybrid_random | 3 / 9 | -0.28 (-0.98, 0.16) | 1 / 1 / 1 | 1 |
| hybrid_v1_cached | 3 / 9 | 4.00 (0.00, 6.16) | 2 / 1 / 0 | 1 |
| qubo_sa | 3 / 9 | 6.62 (0.00, 12.19) | 2 / 1 / 0 | 1 |
| qubo_sb | 3 / 9 | 6.99 (0.00, 12.44) | 2 / 1 / 0 | 1 |
| tunnelling_sa | 3 / 9 | 2.73 (0.00, 5.24) | 2 / 1 / 0 | 1 |

## Interpretation

This run does **not establish that the hybrid beats all three primary methods**. Report the tradeoffs and paired losses; do not claim an overall win.

All reported feasible routes passed a separate accounting/constraint audit. Construction failures are NO_FEASIBLE_INITIAL_SOLUTION, not infeasibility proofs; partial-route costs are excluded from quality comparisons.

The paired table uses jointly feasible runs; see feasibility counts before interpreting it. Shared construction currently gives every method the same coverage failures. Hand-crafted related fixtures are not independent evidence of general performance; bootstrap intervals do not resolve dataset bias.

Traffic and orders are known offline. No live API, mid-route frozen prefix, breakdown rescue, or online order insertion is implemented. QUBO coefficients approximate time/load propagation and use full-route acceptance. Window reordering alone cannot change vehicle assignments; global SA can.

Angel's benchmark adapter reuses her original proposal code and tunnelling acceptance form with the common evaluator, initialization, and budget. It is not a rerun of her original standalone solver. QUBO+SA is a reference/ablation, not Angel's assigned method.

Results depend on wall-clock scheduling. Use max_actions with a generous seconds limit for deterministic debugging, not as an assertion of equal computational work.
