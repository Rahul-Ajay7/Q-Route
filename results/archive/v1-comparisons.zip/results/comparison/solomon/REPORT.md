# Controlled team comparison

Exploratory offline benchmark. Lower INR cost is better. These results do not prove universal superiority.

Window policy: **hard**. Optimization budget: **1.0 seconds per run**; identical initial routes per case/seed.

Construction is shared and timed separately. Solver timing includes QUBO building, decoding, projection, and dynamic validation. Atomic actions may overrun the deadline; overruns are recorded.

| Method | Feasible / attempted | Mean improvement vs own shared initial (%) | Mean optimization seconds | Max budget overrun (s) |
|---|---:|---:|---:|---:|
| classical_sa | 25 / 30 | 4.49 | 0.8336 | 0.0006 |
| tunnelling_sa | 25 / 30 | 6.18 | 0.8335 | 0.0005 |
| qubo_sb | 25 / 30 | 0.11 | 0.8351 | 0.0075 |
| hybrid | 25 / 30 | 5.13 | 0.8337 | 0.0042 |

## Hybrid paired comparisons

Positive difference favours the hybrid. First average paired relative cost differences across seeds within each case; then compare cases. CI uses a case-level bootstrap; p-values use two-sided Wilcoxon and Holm correction across all comparisons.

| Against | Cases / paired seeds | Hybrid cost reduction % (95% CI) | Case wins / ties / losses | Holm p |
|---|---:|---:|---:|---:|
| classical_sa | 5 / 25 | 0.68 (-0.45, 1.99) | 4 / 0 / 1 | 0.3125 |
| qubo_sb | 5 / 25 | 5.02 (2.73, 7.56) | 5 / 0 / 0 | 0.1875 |
| tunnelling_sa | 5 / 25 | -1.17 (-1.87, -0.53) | 0 / 0 / 5 | 0.1875 |

## Interpretation

This run does **not establish that the hybrid beats all three primary methods**. Report the tradeoffs and paired losses; do not claim an overall win.

All reported feasible routes passed a separate accounting/constraint audit. Construction failures are NO_FEASIBLE_INITIAL_SOLUTION, not infeasibility proofs; partial-route costs are excluded from quality comparisons.

The paired table uses jointly feasible runs; see feasibility counts before interpreting it. Shared construction currently gives every method the same coverage failures. Hand-crafted related fixtures are not independent evidence of general performance; bootstrap intervals do not resolve dataset bias.

Traffic and orders are known offline. No live API, mid-route frozen prefix, breakdown rescue, or online order insertion is implemented. QUBO coefficients approximate time/load propagation and use full-route acceptance. Window reordering alone cannot change vehicle assignments; global SA can.

Angel's benchmark adapter reuses her original proposal code and tunnelling acceptance form with the common evaluator, initialization, and budget. It is not a rerun of her original standalone solver. QUBO+SA is a reference/ablation, not Angel's assigned method.

Results depend on wall-clock scheduling. Use max_actions with a generous seconds limit for deterministic debugging, not as an assertion of equal computational work.
