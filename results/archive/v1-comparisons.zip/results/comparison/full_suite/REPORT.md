# Controlled team comparison

Exploratory offline benchmark. Lower INR cost is better. These results do not prove universal superiority.

Window policy: **hard**. Optimization budget: **0.5 seconds per run**; identical initial routes per case/seed.

Construction is shared and timed separately. Solver timing includes QUBO building, decoding, projection, and dynamic validation. Atomic actions may overrun the deadline; overruns are recorded.

| Method | Feasible / attempted | Mean improvement vs own shared initial (%) | Mean optimization seconds | Max budget overrun (s) |
|---|---:|---:|---:|---:|
| classical_sa | 125 / 140 | 8.58 | 0.4465 | 0.0002 |
| tunnelling_sa | 125 / 140 | 9.14 | 0.4465 | 0.0006 |
| qubo_sb | 125 / 140 | 2.41 | 0.4472 | 0.0055 |
| hybrid | 125 / 140 | 8.39 | 0.4465 | 0.0003 |
| qubo_sa | 125 / 140 | 2.16 | 0.4515 | 0.0344 |
| hybrid_no_tabu | 125 / 140 | 8.01 | 0.4466 | 0.0108 |
| hybrid_random | 125 / 140 | 8.21 | 0.4466 | 0.0212 |
| hybrid_no_qubo | 125 / 140 | 8.75 | 0.4465 | 0.0002 |

## Hybrid paired comparisons

Positive difference favours the hybrid. First average paired relative cost differences across seeds within each case; then compare cases. CI uses a case-level bootstrap; p-values use two-sided Wilcoxon and Holm correction across all comparisons.

| Against | Cases / paired seeds | Hybrid cost reduction % (95% CI) | Case wins / ties / losses | Holm p |
|---|---:|---:|---:|---:|
| classical_sa | 25 / 125 | -0.25 (-0.65, 0.12) | 8 / 7 / 10 | 0.7439 |
| hybrid_no_qubo | 25 / 125 | -0.45 (-0.98, 0.09) | 6 / 6 / 13 | 0.3496 |
| hybrid_no_tabu | 25 / 125 | 0.39 (-0.04, 0.82) | 13 / 6 / 6 | 0.2806 |
| hybrid_random | 25 / 125 | 0.16 (-0.31, 0.69) | 11 / 5 / 9 | 0.7439 |
| qubo_sa | 25 / 125 | 6.37 (4.46, 8.38) | 22 / 3 / 0 | 0.0002807 |
| qubo_sb | 25 / 125 | 6.13 (4.22, 8.12) | 21 / 4 / 0 | 0.0003574 |
| tunnelling_sa | 25 / 125 | -0.89 (-1.56, -0.32) | 5 / 6 / 14 | 0.04452 |

## Interpretation

This run does **not establish that the hybrid beats all three primary methods**. Report the tradeoffs and paired losses; do not claim an overall win.

All reported feasible routes passed a separate accounting/constraint audit. Construction failures are NO_FEASIBLE_INITIAL_SOLUTION, not infeasibility proofs; partial-route costs are excluded from quality comparisons.

The paired table uses jointly feasible runs; see feasibility counts before interpreting it. Shared construction currently gives every method the same coverage failures. Hand-crafted related fixtures are not independent evidence of general performance; bootstrap intervals do not resolve dataset bias.

Traffic and orders are known offline. No live API, mid-route frozen prefix, breakdown rescue, or online order insertion is implemented. QUBO coefficients approximate time/load propagation and use full-route acceptance. Window reordering alone cannot change vehicle assignments; global SA can.

Angel's benchmark adapter reuses her original proposal code and tunnelling acceptance form with the common evaluator, initialization, and budget. It is not a rerun of her original standalone solver. QUBO+SA is a reference/ablation, not Angel's assigned method.

Results depend on wall-clock scheduling. Use max_actions with a generous seconds limit for deterministic debugging, not as an assertion of equal computational work.

## Invalid inputs (excluded, never silently repaired)

- TC14.json: Expecting value: line 1 column 1 (char 0)
