# Controlled team comparison

Exploratory offline benchmark. Lower INR cost is better. These results do not prove universal superiority.

Window policy: **hard**. Optimization budget: **0.5 seconds per run**; identical initial routes per case/seed.

Construction is shared and timed separately. Solver timing includes QUBO building, decoding, projection, and dynamic validation. Atomic actions may overrun the deadline; overruns are recorded.

| Method | Feasible / attempted | Mean improvement vs own shared initial (%) | Mean optimization seconds | Max budget overrun (s) |
|---|---:|---:|---:|---:|
| classical_sa | 9 / 9 | 7.98 | 0.5001 | 0.0002 |
| tunnelling_sa | 9 / 9 | 8.71 | 0.5000 | 0.0001 |
| qubo_sb | 9 / 9 | 2.64 | 0.5011 | 0.0021 |
| hybrid | 9 / 9 | 8.93 | 0.5001 | 0.0002 |
| qubo_sa | 9 / 9 | 2.64 | 0.5053 | 0.0106 |
| hybrid_no_tabu | 9 / 9 | 8.41 | 0.5045 | 0.0181 |
| hybrid_random | 9 / 9 | 8.42 | 0.5001 | 0.0001 |
| hybrid_no_qubo | 9 / 9 | 9.22 | 0.5000 | 0.0001 |

## Hybrid paired comparisons

Positive difference favours the hybrid. First average paired relative cost differences across seeds within each case; then compare cases. CI uses a case-level bootstrap; p-values use two-sided Wilcoxon and Holm correction across all comparisons.

| Against | Cases / paired seeds | Hybrid cost reduction % (95% CI) | Case wins / ties / losses | Holm p |
|---|---:|---:|---:|---:|
| classical_sa | 3 / 9 | 0.99 (0.00, 2.96) | 1 / 2 / 0 | 1 |
| hybrid_no_qubo | 3 / 9 | -0.32 (-0.96, 0.00) | 0 / 2 / 1 | 1 |
| hybrid_no_tabu | 3 / 9 | 0.56 (0.00, 1.68) | 1 / 2 / 0 | 1 |
| hybrid_random | 3 / 9 | 0.52 (0.00, 1.56) | 1 / 2 / 0 | 1 |
| qubo_sa | 3 / 9 | 6.35 (0.00, 13.36) | 2 / 1 / 0 | 1 |
| qubo_sb | 3 / 9 | 6.35 (0.00, 13.36) | 2 / 1 / 0 | 1 |
| tunnelling_sa | 3 / 9 | 0.24 (0.00, 0.73) | 1 / 2 / 0 | 1 |

## Interpretation

This run does **not establish that the hybrid beats all three primary methods**. Report the tradeoffs and paired losses; do not claim an overall win.

All reported feasible routes passed a separate accounting/constraint audit. Construction failures are NO_FEASIBLE_INITIAL_SOLUTION, not infeasibility proofs; partial-route costs are excluded from quality comparisons.

The paired table uses jointly feasible runs; see feasibility counts before interpreting it. Shared construction currently gives every method the same coverage failures. Hand-crafted related fixtures are not independent evidence of general performance; bootstrap intervals do not resolve dataset bias.

Traffic and orders are known offline. No live API, mid-route frozen prefix, breakdown rescue, or online order insertion is implemented. QUBO coefficients approximate time/load propagation and use full-route acceptance. Window reordering alone cannot change vehicle assignments; global SA can.

Angel's benchmark adapter reuses her original proposal code and tunnelling acceptance form with the common evaluator, initialization, and budget. It is not a rerun of her original standalone solver. QUBO+SA is a reference/ablation, not Angel's assigned method.

Results depend on wall-clock scheduling. Use max_actions with a generous seconds limit for deterministic debugging, not as an assertion of equal computational work.
