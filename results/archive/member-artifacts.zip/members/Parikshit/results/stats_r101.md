## Recovery of traffic damage (30 scenarios; recovered % = share of the damage won back)

| method | mean | 95% CI | median | std | IQR | min..max | improved | runtime s | solves | accepted/solve |
|---|---|---|---|---|---|---|---|---|---|---|
| do_nothing | 0.0 | 0.0..0.0 | 0.0 | 0.0 | 0.0..0.0 | 0.0..0.0 | 0% | 0.00 | n/a | n/a |
| direct_sa | 6.5 | 4.4..8.7 | 6.9 | 6.1 | 0.0..11.4 | 0.0..17.5 | 63% | 7.78 | 30 | 0.031 |
| qorbit_swap | 6.4 | 4.3..8.5 | 6.9 | 6.0 | 0.0..11.4 | 0.0..17.5 | 63% | 1.85 | 30 | 0.031 |
| qorbit_random | 4.5 | 2.8..6.5 | 2.4 | 5.3 | 0.0..10.1 | 0.0..16.6 | 53% | 1.78 | 30 | 0.023 |

## Paired comparison of `qorbit_flip` against the others (same scenarios)

| vs | mean diff (pp) | wins / ties / losses | Wilcoxon p |
|---|---|---|---|

Wilcoxon drops tied pairs, so with many ties it has little power; read wins/ties/losses alongside it.

## Effect on distance, route time, fuel and lateness (mean per scenario)

Damage = (damaged plan) - (pre-event plan); a method's change = (its final plan) - (damaged plan). Negative change = improvement.

| | distance km | route hours | fuel L | lateness min | vehicles | total cost INR |
|---|---|---|---|---|---|---|
| pre-event plan (absolute) | 1975.6 | 63.4 | 194.5 | 0.0 | 22.0 | 44917.1 |
| damage caused by the event | +0.0 | +5.4 | +8.9 | +337.8 | +0.0 | +5032.1 |
| do_nothing: change vs damaged | +0.00 | +0.00 | +0.00 | +0.00 | +0.00 | +0.00 |
| direct_sa: change vs damaged | -5.12 | -0.12 | -0.66 | -26.85 | +0.00 | -364.65 |
| qorbit_swap: change vs damaged | -5.06 | -0.11 | -0.65 | -26.48 | +0.00 | -358.82 |
| qorbit_random: change vs damaged | -4.48 | -0.09 | -0.56 | -18.34 | +0.00 | -263.69 |

Cost components of the damage (mean INR): distance +0, time +807, fuel +847, late +3378, vehicle +0
