## Recovery of traffic damage (30 scenarios; recovered % = share of the damage won back)

| method | mean | 95% CI | median | std | IQR | min..max | improved | runtime s | solves | accepted/solve |
|---|---|---|---|---|---|---|---|---|---|---|
| do_nothing | 0.0 | 0.0..0.0 | 0.0 | 0.0 | 0.0..0.0 | 0.0..0.0 | 0% | 0.00 | n/a | n/a |
| direct_sa | 17.6 | 14.4..20.6 | 15.3 | 8.9 | 10.6..25.2 | 3.1..35.7 | 100% | 12.69 | 30 | 0.153 |
| qorbit_swap | 13.1 | 10.2..16.3 | 11.8 | 8.7 | 5.9..17.7 | 0.0..31.7 | 97% | 2.61 | 30 | 0.104 |
| qorbit_random | 15.4 | 12.9..17.8 | 14.5 | 7.1 | 10.0..21.8 | 4.9..28.9 | 100% | 2.36 | 30 | 0.131 |

## Paired comparison of `qorbit_swap` against the others (same scenarios)

| vs | mean diff (pp) | wins / ties / losses | Wilcoxon p |
|---|---|---|---|
| do_nothing | +13.05 | 29 / 1 / 0 | 0.000 |
| direct_sa | -4.51 | 0 / 6 / 24 | 0.000 |
| qorbit_random | -2.38 | 8 / 0 / 22 | 0.015 |

Wilcoxon drops tied pairs, so with many ties it has little power; read wins/ties/losses alongside it.

## Effect on distance, route time, fuel and lateness (mean per scenario)

Damage = (damaged plan) - (pre-event plan); a method's change = (its final plan) - (damaged plan). Negative change = improvement.

| | distance km | route hours | fuel L | lateness min | vehicles | total cost INR |
|---|---|---|---|---|---|---|
| pre-event plan (absolute) | 2198.3 | 64.4 | 221.9 | 0.0 | 21.0 | 47836.3 |
| damage caused by the event | +0.0 | +6.8 | +10.4 | +471.6 | +0.0 | +6728.3 |
| do_nothing: change vs damaged | +0.00 | +0.00 | +0.00 | +0.00 | +0.00 | +0.00 |
| direct_sa: change vs damaged | -21.17 | -0.65 | -2.84 | -75.07 | +0.00 | -1181.62 |
| qorbit_swap: change vs damaged | -20.28 | -0.28 | -2.35 | -56.65 | +0.00 | -892.30 |
| qorbit_random: change vs damaged | -41.75 | -0.30 | -4.56 | -38.22 | +0.00 | -985.62 |

Cost components of the damage (mean INR): distance +0, time +1024, fuel +989, late +4716, vehicle +0
