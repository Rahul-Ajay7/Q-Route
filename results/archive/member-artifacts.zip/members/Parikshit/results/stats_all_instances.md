## Recovery of traffic damage (90 scenarios; recovered % = share of the damage won back)

| method | mean | 95% CI | median | std | IQR | min..max | improved | runtime s | solves | accepted/solve |
|---|---|---|---|---|---|---|---|---|---|---|
| do_nothing | 0.0 | 0.0..0.0 | 0.0 | 0.0 | 0.0..0.0 | 0.0..0.0 | 0% | 0.00 | n/a | n/a |
| direct_sa | 8.0 | 6.0..10.1 | 4.7 | 9.5 | 0.0..13.4 | 0.0..35.7 | 54% | 10.69 | 30 | 0.061 |
| qorbit_swap | 6.5 | 4.9..8.1 | 3.3 | 8.1 | 0.0..11.5 | 0.0..31.7 | 53% | 2.12 | 30 | 0.045 |
| qorbit_random | 6.7 | 5.0..8.5 | 2.4 | 8.2 | 0.0..12.4 | 0.0..28.9 | 51% | 1.98 | 30 | 0.051 |

## Paired comparison of `qorbit_swap` against the others (same scenarios)

| vs | mean diff (pp) | wins / ties / losses | Wilcoxon p |
|---|---|---|---|
| do_nothing | +6.48 | 48 / 42 / 0 | 0.000 |
| direct_sa | -1.53 | 0 / 62 / 28 | 0.000 |
| qorbit_random | -0.18 | 15 / 53 / 22 | 0.541 |

Wilcoxon drops tied pairs, so with many ties it has little power; read wins/ties/losses alongside it.

## Effect on distance, route time, fuel and lateness (mean per scenario)

Damage = (damaged plan) - (pre-event plan); a method's change = (its final plan) - (damaged plan). Negative change = improvement.

| | distance km | route hours | fuel L | lateness min | vehicles | total cost INR |
|---|---|---|---|---|---|---|
| pre-event plan (absolute) | 1719.5 | 99.8 | 173.9 | 0.0 | 18.3 | 45819.9 |
| damage caused by the event | +0.0 | +4.5 | +7.2 | +322.4 | +0.0 | +4583.1 |
| do_nothing: change vs damaged | +0.00 | +0.00 | +0.00 | +0.00 | +0.00 | +0.00 |
| direct_sa: change vs damaged | -8.76 | -0.26 | -1.17 | -33.97 | +0.00 | -515.42 |
| qorbit_swap: change vs damaged | -8.44 | -0.13 | -1.00 | -27.71 | +0.00 | -417.04 |
| qorbit_random: change vs damaged | -15.41 | -0.13 | -1.71 | -18.85 | +0.00 | -416.44 |

Cost components of the damage (mean INR): distance +0, time +676, fuel +684, late +3224, vehicle +0
