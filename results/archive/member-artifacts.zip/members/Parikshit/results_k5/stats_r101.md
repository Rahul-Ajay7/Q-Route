## Recovery of traffic damage (30 scenarios; recovered % = share of the damage won back)

| method | mean | 95% CI | median | std | IQR | min..max | improved | runtime s | solves | accepted/solve |
|---|---|---|---|---|---|---|---|---|---|---|
| do_nothing | 0.0 | 0.0..0.0 | 0.0 | 0.0 | 0.0..0.0 | 0.0..0.0 | 0% | 0.00 | n/a | n/a |
| direct_sa | 6.5 | 4.4..8.6 | 6.9 | 6.1 | 0.0..11.4 | 0.0..17.5 | 63% | 8.70 | 30 | 0.031 |
| qorbit_flip | 4.3 | 2.4..6.2 | 0.0 | 5.5 | 0.0..9.0 | 0.0..16.0 | 47% | 11.67 | 30 | 0.032 |
| qorbit_swap | 4.3 | 2.5..6.3 | 0.0 | 5.5 | 0.0..9.0 | 0.0..16.0 | 47% | 2.12 | 30 | 0.032 |
| qorbit_random | 2.2 | 1.0..3.7 | 0.0 | 3.8 | 0.0..2.9 | 0.0..13.2 | 33% | 11.36 | 30 | 0.018 |

## Paired comparison of `qorbit_flip` against the others (same scenarios)

| vs | mean diff (pp) | wins / ties / losses | Wilcoxon p |
|---|---|---|---|
| do_nothing | +4.28 | 14 / 16 / 0 | 0.001 |
| direct_sa | -2.19 | 0 / 21 / 9 | 0.008 |
| qorbit_swap | +0.00 | 0 / 30 / 0 | 1.000 |
| qorbit_random | +2.04 | 8 / 22 / 0 | 0.012 |

Wilcoxon drops tied pairs, so with many ties it has little power; read wins/ties/losses alongside it.
