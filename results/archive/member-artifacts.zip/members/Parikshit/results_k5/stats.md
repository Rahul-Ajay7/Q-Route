## Recovery of traffic damage (90 scenarios; recovered % = share of the damage won back)

| method | mean | 95% CI | median | std | IQR | min..max | improved | runtime s | solves | accepted/solve |
|---|---|---|---|---|---|---|---|---|---|---|
| do_nothing | 0.0 | 0.0..0.0 | 0.0 | 0.0 | 0.0..0.0 | 0.0..0.0 | 0% | 0.00 | n/a | n/a |
| direct_sa | 8.4 | 6.4..10.5 | 5.8 | 10.0 | 0.0..14.6 | 0.0..35.7 | 54% | 12.94 | 30 | 0.060 |
| qorbit_flip | 4.3 | 2.5..6.2 | 0.0 | 5.5 | 0.0..9.0 | 0.0..16.0 | 47% | 11.67 | 30 | 0.032 |
| qorbit_swap | 6.1 | 4.4..7.9 | 0.0 | 8.3 | 0.0..10.8 | 0.0..31.7 | 49% | 2.59 | 30 | 0.049 |
| qorbit_random | 5.5 | 4.0..7.3 | 0.0 | 8.2 | 0.0..9.7 | 0.0..31.1 | 44% | 14.23 | 30 | 0.055 |

## Paired comparison of `qorbit_swap` against the others (same scenarios)

| vs | mean diff (pp) | wins / ties / losses | Wilcoxon p |
|---|---|---|---|
| do_nothing | +6.13 | 44 / 46 / 0 | 0.000 |
| direct_sa | -2.31 | 2 / 53 / 35 | 0.000 |
| qorbit_flip | +0.00 | 0 / 30 / 0 | 1.000 |
| qorbit_random | +0.59 | 19 / 53 / 18 | 0.213 |

Wilcoxon drops tied pairs, so with many ties it has little power; read wins/ties/losses alongside it.
