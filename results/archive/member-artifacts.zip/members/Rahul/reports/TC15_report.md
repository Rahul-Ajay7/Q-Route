# TC15.json — internal TC08

![Route and cost comparison](../plots/TC15_comparison.png)

| Algorithm | Objective score | Improvement vs greedy | Feasible | Total compute seconds |
|---|---:|---:|---|---:|
| GREEDY | 405.86 | 0.00% | False | 0.0009 |
| SB | 405.43 | 0.11% | False | 0.0171 |
| SA | 405.43 | 0.11% | False | 0.1877 |

## Distance and estimated fuel

| Algorithm | Distance (coordinate units) | Travel minutes | Assumed km | Estimated liters | Fuel cost |
|---|---:|---:|---:|---:|---:|
| GREEDY | 144.951846 | 144.95 | 144.951846 | 14.495185 | 1449.518464 INR |
| SB | 144.796049 | 144.79 | 144.796049 | 14.479605 | 1447.960494 INR |
| SA | 144.796049 | 144.79 | 144.796049 | 14.479605 | 1447.960494 INR |

Assumptions: 1.0 km per coordinate unit; 10.0 L/100 km; 100.0 INR/L.
Distance is synthetic straight-line distance including depot legs. Fuel excludes idling and load effects.
Objective: weighted; weights: distance=0.4, travel time=0.4, fuel cost=0.2.
The weighted score combines raw units without normalization; weights set their relative influence.

## Example: V1 visiting order

- **GREEDY**: 0 → 4 → 2 → 11 → 0 (72.00 travel minutes)
- **SB**: 0 → 2 → 11 → 4 → 0 (71.84 travel minutes)
- **SA**: 0 → 2 → 11 → 4 → 0 (71.84 travel minutes)

Customer labels and colors match across the route maps. The star is the depot.
Routes use synthetic coordinates; they are not actual road maps.
This is one seeded run, not a statistical claim that SB or SA is always better.
Time windows/capacity are checked after decoding; online vehicle reassignment is not implemented.

Raw results: [TC15_results.csv](../results/TC15_results.csv); route schedules: [TC15_routes.json](../results/TC15_routes.json).


## Search diagnostics

| Method | Original pass travel min | Raw valid assignments | Solver calls | Rebuilt QUBOs |
|---|---:|---:|---:|---:|
| SB | 144.79 | 20.31% | 8 | 2 |
| SA | 144.79 | 100.00% | 8 | 2 |

Adaptive settings: 2 passes, stride 2, 3 seeded restarts. Each method rebuilds QUBOs from its own accepted route. These runs do not have matched wall-clock budgets.
**GREEDY: unserved customer IDs [1, 6, 7, 8, 9, 12].** Red crosses mark these customers. Travel costs cover partial routes; cost reductions do not represent a complete feasible solution.
**SB: unserved customer IDs [1, 6, 7, 8, 9, 12].** Red crosses mark these customers. Travel costs cover partial routes; cost reductions do not represent a complete feasible solution.
**SA: unserved customer IDs [1, 6, 7, 8, 9, 12].** Red crosses mark these customers. Travel costs cover partial routes; cost reductions do not represent a complete feasible solution.