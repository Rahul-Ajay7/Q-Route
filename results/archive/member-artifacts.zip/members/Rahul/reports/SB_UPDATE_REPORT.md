# SB + QUBO weighted-objective results

Objective: 0.4 ? geometric distance + 0.4 ? actual travel minutes + 0.2 ? estimated fuel cost.

Example assumptions: 1 km per synthetic coordinate unit; 10 L/100 km; 100 INR/L. These are configurable estimates, not measured road distances or fuel prices.

16 tests passed. Export audit passed: 85 rows, 28 route records; objective and component totals agree. SB and SA did not worsen their own greedy objective.

28 valid cases: 25 feasible, 3 incomplete for each method. TC14.json is an existing CSV index rather than valid JSON; the --all command exits 1 to flag this input.

Inputs are offline, vehicle assignments stay fixed, and capacity/time windows are checked after decoding. No global-optimality claim is made.

Weights combine raw units without normalization. Fuel cost is proportional to distance in this constant-consumption model; traffic changes time. Incomplete cases report partial routes.

Previous time-only results, reports, and plots are preserved in [the archive](../results/archive/time_only/). The historical comparison script applies only to --objective travel_time.

| Source file / internal ID | SB travel minutes | Geometric distance | Estimated liters | Estimated fuel cost (INR) | Objective score | Feasible |
|---|---:|---:|---:|---:|---:|---|
| TC03 / TC01 | 137.26 | 137.258022 | 13.725802 | 1372.580218 | 384.323252 | True |
| TC11 / TC04 | 827.99 | 827.977101 | 82.797710 | 8279.771007 | 2318.341042 | True |
| TC17 / TC09 | 232.45 | 232.441410 | 23.244141 | 2324.414105 | 650.839385 | True |
| TC15 / TC08 | 144.79 | 144.796049 | 14.479605 | 1447.960494 | 405.426519 | False |
