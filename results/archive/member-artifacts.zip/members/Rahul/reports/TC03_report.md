# TC03.json — internal TC01

![Route and cost comparison](../plots/TC03_comparison.png)

| Algorithm | Objective score | Improvement vs greedy | Feasible | Total compute seconds |
|---|---:|---:|---|---:|
| GREEDY | 410.76 | 0.00% | True | 0.0001 |
| SB | 384.32 | 6.44% | True | 0.0105 |
| SA | 384.32 | 6.44% | True | 0.2272 |

## Distance and estimated fuel

| Algorithm | Distance (coordinate units) | Travel minutes | Assumed km | Estimated liters | Fuel cost |
|---|---:|---:|---:|---:|---:|
| GREEDY | 146.698659 | 146.70 | 146.698659 | 14.669866 | 1466.986591 INR |
| SB | 137.258022 | 137.26 | 137.258022 | 13.725802 | 1372.580218 INR |
| SA | 137.258022 | 137.26 | 137.258022 | 13.725802 | 1372.580218 INR |

Assumptions: 1.0 km per coordinate unit; 10.0 L/100 km; 100.0 INR/L.
Distance is synthetic straight-line distance including depot legs. Fuel excludes idling and load effects.
Objective: weighted; weights: distance=0.4, travel time=0.4, fuel cost=0.2.
The weighted score combines raw units without normalization; weights set their relative influence.

## Example: V1 visiting order

- **GREEDY**: 0 → 4 → 1 → 3 → 2 → 5 → 0 (146.70 travel minutes)
- **SB**: 0 → 4 → 1 → 2 → 3 → 5 → 0 (137.26 travel minutes)
- **SA**: 0 → 4 → 1 → 2 → 3 → 5 → 0 (137.26 travel minutes)

Customer labels and colors match across the route maps. The star is the depot.
Routes use synthetic coordinates; they are not actual road maps.
This is one seeded run, not a statistical claim that SB or SA is always better.
Time windows/capacity are checked after decoding; online vehicle reassignment is not implemented.

Raw results: [TC03_results.csv](../results/TC03_results.csv); route schedules: [TC03_routes.json](../results/TC03_routes.json).


## Search diagnostics

| Method | Original pass travel min | Raw valid assignments | Solver calls | Rebuilt QUBOs |
|---|---:|---:|---:|---:|
| SB | 137.26 | 0.00% | 4 | 1 |
| SA | 137.26 | 100.00% | 4 | 1 |

Adaptive settings: 2 passes, stride 2, 3 seeded restarts. Each method rebuilds QUBOs from its own accepted route. These runs do not have matched wall-clock budgets.