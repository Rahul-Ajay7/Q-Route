# TC17.json — internal TC09

![Route and cost comparison](../plots/TC17_comparison.png)

| Algorithm | Objective score | Improvement vs greedy | Feasible | Total compute seconds |
|---|---:|---:|---|---:|
| GREEDY | 734.97 | 0.00% | True | 0.0004 |
| SB | 650.84 | 11.45% | True | 0.0767 |
| SA | 650.84 | 11.45% | True | 0.8925 |

## Distance and estimated fuel

| Algorithm | Distance (coordinate units) | Travel minutes | Assumed km | Estimated liters | Fuel cost |
|---|---:|---:|---:|---:|---:|
| GREEDY | 262.487568 | 262.50 | 262.487568 | 26.248757 | 2624.875680 INR |
| SB | 232.441410 | 232.45 | 232.441410 | 23.244141 | 2324.414105 INR |
| SA | 232.441410 | 232.45 | 232.441410 | 23.244141 | 2324.414105 INR |

Assumptions: 1.0 km per coordinate unit; 10.0 L/100 km; 100.0 INR/L.
Distance is synthetic straight-line distance including depot legs. Fuel excludes idling and load effects.
Objective: weighted; weights: distance=0.4, travel time=0.4, fuel cost=0.2.
The weighted score combines raw units without normalization; weights set their relative influence.

## Example: V1 visiting order

- **GREEDY**: 0 → 3 → 4 → 8 → 1 → 10 → 9 → 5 → 6 → 7 → 2 → 0 (262.50 travel minutes)
- **SB**: 0 → 3 → 4 → 8 → 1 → 10 → 6 → 5 → 9 → 2 → 7 → 0 (232.45 travel minutes)
- **SA**: 0 → 3 → 4 → 8 → 1 → 10 → 6 → 5 → 9 → 2 → 7 → 0 (232.45 travel minutes)

Customer labels and colors match across the route maps. The star is the depot.
Routes use synthetic coordinates; they are not actual road maps.
This is one seeded run, not a statistical claim that SB or SA is always better.
Time windows/capacity are checked after decoding; online vehicle reassignment is not implemented.

Raw results: [TC17_results.csv](../results/TC17_results.csv); route schedules: [TC17_routes.json](../results/TC17_routes.json).


## Search diagnostics

| Method | Original pass travel min | Raw valid assignments | Solver calls | Rebuilt QUBOs |
|---|---:|---:|---:|---:|
| SB | 262.50 | 0.00% | 26 | 8 |
| SA | 232.45 | 100.00% | 14 | 4 |

Adaptive settings: 2 passes, stride 2, 3 seeded restarts. Each method rebuilds QUBOs from its own accepted route. These runs do not have matched wall-clock budgets.