"""Audit updated benchmark artifacts and refresh representative reports' inputs."""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
ARCHIVE = RESULTS / 'archive'
REPORTS = ROOT / 'reports'

def main():
    before = list(csv.DictReader((ARCHIVE/'sb_results_before_updates.csv').open(encoding='utf-8-sig')))
    after = list(csv.DictReader((RESULTS/'sb_results.csv').open(encoding='utf-8-sig')))
    if any(r.get('objective') == 'weighted' for r in after):
        raise ValueError('The historical audit requires --objective travel_time. Weighted scores cannot be compared with the archived time-only benchmark. Use visualize_results.py for weighted case reports.')
    details = json.loads((RESULTS/'sb_routes.json').read_text(encoding='utf-8-sig'))
    old = {(r['source_file'],r['algorithm']):r for r in before}
    assert len(after) == len(before) == 85
    assert len(details) == 28
    for row in after:
        if row['algorithm'] == 'INPUT':
            continue
        previous = old[(row['source_file'],row['algorithm'])]
        assert row['feasible'] == previous['feasible']
        assert row['unserved_ids'] == previous['unserved_ids']
        assert float(row['final_travel_minutes']) <= float(previous['final_travel_minutes']) + 1e-7
        if row['algorithm'] != 'GREEDY':
            assert abs(float(row['reference_travel_minutes']) - float(previous['final_travel_minutes'])) < 1e-7
            assert int(row['raw_valid_samples']) + int(row['projected_samples']) == int(row['solver_calls']) * int(row['samples'])
    for detail in details:
        for method, result in detail['algorithms'].items():
            row = next(r for r in after if r['source_file']==detail['source_file'] and r['algorithm']==method)
            assert result['feasible'] == (row['feasible']=='True')
            assert result['unserved_ids'] == json.loads(row['unserved_ids'])
            assert abs(sum(r.get('travel_minutes', r['cost']) for r in result['routes']) - float(row['final_travel_minutes'])) < 1e-7
            original = json.loads((ROOT/'test_cases'/detail['source_file']).read_text(encoding='utf-8-sig'))
            served = [c for route in result['routes'] for c in route['customers']]
            assert len(served)==len(set(served))
            assert set(served)|set(result['unserved_ids']) == {c['id'] for c in original['customers']}
    report = ['# SB + QUBO update results', '',
              'Seed 42; 16 replicas; 200 integration steps / SA sweeps; blocks of 5.',
              'Updated search: up to 2 overlapping passes, stride 2, 3 seeded restarts per window.',
              'Both methods receive these settings. Adaptive matrices follow each method\'s accepted routes.', '',
              '14 unit tests passed. Export audit passed: 85 rows and 28 route records.',
              '28 valid inputs: 25 feasible, 3 incomplete. TC14.json remains invalid.', '',
              '| Method | Improved feasible cases vs greedy: before | After | Cases improved vs old method | Total search seconds: before | After |',
              '|---|---:|---:|---:|---:|---:|']
    for method in ['SB','SA']:
        group = [r for r in after if r['algorithm']==method and r['feasible']=='True']
        previous = [old[(r['source_file'],method)] for r in group]
        old_improved = sum(float(r['improvement_minutes'])>1e-8 for r in previous)
        new_improved = sum(float(r['improvement_minutes'])>1e-8 for r in group)
        better = sum(float(n['final_travel_minutes'])<float(o['final_travel_minutes'])-1e-8 for n,o in zip(group,previous))
        old_time = sum(float(r['solver_decode_seconds']) for r in before if r['algorithm']==method)
        new_time = sum(float(r['solver_decode_seconds']) for r in after if r['algorithm']==method)
        report.append(f'| {method} | {old_improved}/25 | {new_improved}/25 | {better}/25 | {old_time:.3f} | {new_time:.3f} |')
        print(method,'improved vs greedy',new_improved,'improved vs previous',better,'total search seconds',round(new_time,3))
    report += ['', '## Representative SB results', '',
               '| Source file | Condition | Greedy minutes | Old SB minutes | Updated SB minutes | Reduction vs greedy |',
               '|---|---|---:|---:|---:|---:|']
    for stem in ['TC11','TC17','TC15']:
        rows = [r for r in after if r['source_file']==stem+'.json']
        with (RESULTS/(stem+'_results.csv')).open('w',newline='',encoding='utf-8') as handle:
            writer=csv.DictWriter(handle,fieldnames=list(after[0]))
            writer.writeheader()
            writer.writerows(rows)
        case = next(d for d in details if d['source_file']==stem+'.json')
        (RESULTS/(stem+'_routes.json')).write_text(json.dumps([case],indent=2,allow_nan=False),encoding='utf-8')
        r = next(r for r in rows if r['algorithm']=='SB')
        initial, final = float(r['initial_travel_minutes']),float(r['final_travel_minutes'])
        previous = float(old[(stem+'.json','SB')]['final_travel_minutes'])
        report.append(f'| {stem}.json | {r["title"]} | {initial:.2f} | {previous:.2f} | {final:.2f} | {(initial-final)/initial*100:.2f}% |')
    report += ['', 'TC15 values cover partial routes: six customers remain unserved. Capacity is unchanged.',
               'More solves improve exploration and increase runtime. These comparisons are not matched-wall-clock experiments.',
               'Raw valid assignment rates are in sb_results.csv; projection repairs are counted separately.',
               'The original pass result is retained; no updated case regressed in travel cost or feasibility.',
               'Manual SB parameter controls are available; no automatic parameter tuning was performed.',
               'Customer reassignment, multi-trip routing and online replanning remain outside this update.', '',
               '![Updated medium-fleet comparison](../plots/TC11_comparison.png)', '']
    REPORTS.mkdir(parents=True, exist_ok=True)
    (REPORTS/'SB_UPDATE_REPORT.md').write_text('\n'.join(report),encoding='utf-8')
    print('Audit passed; representative exports refreshed; SB_UPDATE_REPORT.md saved.')

if __name__ == '__main__':
    main()
