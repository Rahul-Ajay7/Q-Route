# TC11.json — internal TC04

![Route and cost comparison](../plots/TC11_comparison.png)

| Algorithm | Travel minutes | Improvement vs greedy | Feasible | Total compute seconds |
|---|---:|---:|---|---:|
| GREEDY | 902.26 | 0.00% | True | 0.0088 |
| SB | 827.99 | 8.23% | True | 0.3063 |
| SA | 827.99 | 8.23% | True | 6.3395 |

## Example: V1 visiting order

- **GREEDY**: 0 → 19 → 47 → 45 → 1 → 50 → 16 → 46 → 10 → 8 → 37 → 41 → 0 (104.90 travel minutes)
- **SB**: 0 → 19 → 47 → 1 → 45 → 50 → 16 → 8 → 37 → 41 → 10 → 46 → 0 (94.70 travel minutes)
- **SA**: 0 → 19 → 47 → 1 → 45 → 50 → 16 → 8 → 37 → 41 → 10 → 46 → 0 (94.70 travel minutes)

Customer labels and colors match across the route maps. The star is the depot.
Routes use synthetic coordinates; they are not actual road maps.
This is one seeded run, not a statistical claim that SB or SA is always better.
Time windows/capacity are checked after decoding; online vehicle reassignment is not implemented.

Raw results: [TC11_results.csv](../results/TC11_results.csv); route schedules: [TC11_routes.json](../results/TC11_routes.json).


## Search diagnostics

| Method | Original pass travel min | Raw valid assignments | Solver calls | Rebuilt QUBOs |
|---|---:|---:|---:|---:|
| SB | 879.17 | 0.21% | 118 | 36 |
| SA | 859.02 | 100.00% | 118 | 36 |

Adaptive settings: 2 passes, stride 2, 3 seeded restarts. Each method rebuilds QUBOs from its own accepted route. These runs do not have matched wall-clock budgets.