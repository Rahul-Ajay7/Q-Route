# TC17.json — internal TC09

![Route and cost comparison](../plots/TC17_comparison.png)

| Algorithm | Travel minutes | Improvement vs greedy | Feasible | Total compute seconds |
|---|---:|---:|---|---:|
| GREEDY | 262.50 | 0.00% | True | 0.0003 |
| SB | 232.45 | 11.45% | True | 0.0760 |
| SA | 232.45 | 11.45% | True | 0.8049 |

## Example: V1 visiting order

- **GREEDY**: 0 → 3 → 4 → 8 → 1 → 10 → 9 → 5 → 6 → 7 → 2 → 0 (262.50 travel minutes)
- **SB**: 0 → 3 → 4 → 8 → 1 → 10 → 6 → 5 → 9 → 2 → 7 → 0 (232.45 travel minutes)
- **SA**: 0 → 3 → 4 → 8 → 1 → 10 → 6 → 5 → 9 → 2 → 7 → 0 (232.45 travel minutes)

Customer labels and colors match across the route maps. The star is the depot.
Routes use synthetic coordinates; they are not actual road maps.
This is one seeded run, not a statistical claim that SB or SA is always better.
Time windows/capacity are checked after decoding; online vehicle reassignment is not implemented.

Raw results: [TC17_results.csv](../results/TC17_results.csv); route schedules: [TC17_routes.json](../results/TC17_routes.json).


## Search diagnostics

| Method | Original pass travel min | Raw valid assignments | Solver calls | Rebuilt QUBOs |
|---|---:|---:|---:|---:|
| SB | 262.50 | 0.00% | 26 | 8 |
| SA | 232.45 | 100.00% | 14 | 4 |

Adaptive settings: 2 passes, stride 2, 3 seeded restarts. Each method rebuilds QUBOs from its own accepted route. These runs do not have matched wall-clock budgets.