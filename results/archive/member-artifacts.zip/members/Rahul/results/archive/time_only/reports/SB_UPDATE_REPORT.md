# SB + QUBO update results

Seed 42; 16 replicas; 200 integration steps / SA sweeps; blocks of 5.
Updated search: up to 2 overlapping passes, stride 2, 3 seeded restarts per window.
Both methods receive these settings. Adaptive matrices follow each method's accepted routes.

14 unit tests passed. Export audit passed: 85 rows and 28 route records.
28 valid inputs: 25 feasible, 3 incomplete. TC14.json remains invalid.

| Method | Improved feasible cases vs greedy: before | After | Cases improved vs old method | Total search seconds: before | After |
|---|---:|---:|---:|---:|---:|
| SB | 18/25 | 21/25 | 18/25 | 0.742 | 3.869 |
| SA | 21/25 | 22/25 | 18/25 | 16.933 | 79.771 |

## Representative SB results

| Source file | Condition | Greedy minutes | Old SB minutes | Updated SB minutes | Reduction vs greedy |
|---|---|---:|---:|---:|---:|
| TC11.json | Medium fleet baseline | 902.26 | 879.17 | 827.99 | 8.23% |
| TC17.json | Narrow feasible windows | 262.50 | 262.50 | 232.45 | 11.45% |
| TC15.json | Insufficient total capacity | 144.95 | 144.79 | 144.79 | 0.11% |

TC15 values cover partial routes: six customers remain unserved. Capacity is unchanged.
More solves improve exploration and increase runtime. These comparisons are not matched-wall-clock experiments.
Raw valid assignment rates are in sb_results.csv; projection repairs are counted separately.
The original pass result is retained; no updated case regressed in travel cost or feasibility.
Manual SB parameter controls are available; no automatic parameter tuning was performed.
Customer reassignment, multi-trip routing and online replanning remain outside this update.

![Updated medium-fleet comparison](../plots/TC11_comparison.png)
