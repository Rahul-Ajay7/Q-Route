# TC15.json — internal TC08

![Route and cost comparison](../plots/TC15_comparison.png)

| Algorithm | Travel minutes | Improvement vs greedy | Feasible | Total compute seconds |
|---|---:|---:|---|---:|
| GREEDY | 144.95 | 0.00% | False | 0.0006 |
| SB | 144.79 | 0.11% | False | 0.0160 |
| SA | 144.79 | 0.11% | False | 0.1660 |

## Example: V1 visiting order

- **GREEDY**: 0 → 4 → 2 → 11 → 0 (72.00 travel minutes)
- **SB**: 0 → 2 → 11 → 4 → 0 (71.84 travel minutes)
- **SA**: 0 → 2 → 11 → 4 → 0 (71.84 travel minutes)

Customer labels and colors match across the route maps. The star is the depot.
Routes use synthetic coordinates; they are not actual road maps.
This is one seeded run, not a statistical claim that SB or SA is always better.
Time windows/capacity are checked after decoding; online vehicle reassignment is not implemented.

Raw results: [TC15_results.csv](../results/TC15_results.csv); route schedules: [TC15_routes.json](../results/TC15_routes.json).


## Search diagnostics

| Method | Original pass travel min | Raw valid assignments | Solver calls | Rebuilt QUBOs |
|---|---:|---:|---:|---:|
| SB | 144.79 | 20.31% | 8 | 2 |
| SA | 144.79 | 100.00% | 8 | 2 |

Adaptive settings: 2 passes, stride 2, 3 seeded restarts. Each method rebuilds QUBOs from its own accepted route. These runs do not have matched wall-clock budgets.
**GREEDY: unserved customer IDs [1, 6, 7, 8, 9, 12].** Red crosses mark these customers. Travel costs cover partial routes; cost reductions do not represent a complete feasible solution.
**SB: unserved customer IDs [1, 6, 7, 8, 9, 12].** Red crosses mark these customers. Travel costs cover partial routes; cost reductions do not represent a complete feasible solution.
**SA: unserved customer IDs [1, 6, 7, 8, 9, 12].** Red crosses mark these customers. Travel costs cover partial routes; cost reductions do not represent a complete feasible solution.